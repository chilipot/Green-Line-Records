create view managers as
  select `banking`.`bank`.`job`       AS `job`,
         `banking`.`bank`.`marital`   AS `marital`,
         `banking`.`bank`.`education` AS `education`,
         `banking`.`bank`.`balance`   AS `balance`,
         `banking`.`bank`.`approved`  AS `approved`
  from `banking`.`bank`
  where (`banking`.`bank`.`job` = 'management');

