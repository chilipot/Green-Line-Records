create view mgrs as
  select `banking`.`bank`.`age` AS `age`, `banking`.`bank`.`job` AS `job`, `banking`.`bank`.`marital` AS `marital`
  from `banking`.`bank`
  where (`banking`.`bank`.`job` = 'management');

